import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles as SparkleIcon } from "lucide-react";

import { SiteHeader, SiteFooter } from "@/components/site-chrome";
import { kidsThemes } from "@/lib/kids-themes-data";

// Map each theme id to a representative image from available assets
import bb01 from "@/assets/pkg/birthday/baby-boy/bday-boy-01.jpg";
import bb02 from "@/assets/pkg/birthday/baby-boy/bday-boy-02.jpg";
import bb03 from "@/assets/pkg/birthday/baby-boy/bday-boy-03.jpg";
import bb04 from "@/assets/pkg/birthday/baby-boy/bday-boy-04.jpg";
import bb05 from "@/assets/pkg/birthday/baby-boy/bday-boy-05.jpg";
import bb06 from "@/assets/pkg/birthday/baby-boy/bday-boy-06.jpg";
import bb07 from "@/assets/pkg/birthday/baby-boy/bday-boy-07.jpg";
import bg01 from "@/assets/pkg/birthday/baby-girl/bday-girl-01.jpg";
import bg02 from "@/assets/pkg/birthday/baby-girl/bday-girl-02.jpg";
import bg03 from "@/assets/pkg/birthday/baby-girl/bday-girl-03.jpg";
import bg04 from "@/assets/pkg/birthday/baby-girl/bday-girl-04.jpg";
import bg05 from "@/assets/pkg/birthday/baby-girl/bday-girl-05.jpg";
import bg06 from "@/assets/pkg/birthday/baby-girl/bday-girl-06.jpg";
import bg07 from "@/assets/pkg/birthday/baby-girl/bday-girl-07.jpg";
import celebCar from "@/assets/celeb-car.jpg";
import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";
import g4 from "@/assets/gallery-4.jpg";
import g5 from "@/assets/gallery-5.jpg";
import pkgKids from "@/assets/pkg-kids.jpg";

const themeImages: Record<string, string> = {
  "cars": celebCar,
  "spiderman": bb01,
  "jungle-safari": g2,
  "dinosaurs": bb02,
  "avengers": bb03,
  "space": bb04,
  "lego": bb05,
  "farm": bb06,
  "football": bb07,
  "cricket": g3,
  "unicorn": bg01,
  "mermaid": bg02,
  "butterfly": bg03,
  "rainbow": bg04,
  "candyland": bg05,
  "princess": bg06,
  "barbie": bg07,
  "frozen": g1,
  "minnie-mouse": bg04,
  "peppa-pig": bg06,
};

const themeTaglines: Record<string, string> = {
  "cars": "Zoom into a racing-themed birthday",
  "spiderman": "Swing into a web of birthday fun",
  "jungle-safari": "A wild adventure awaits",
  "dinosaurs": "Roar into a prehistoric party",
  "avengers": "Assemble for an epic celebration",
  "space": "Blast off into a cosmic birthday",
  "lego": "Build the perfect birthday together",
  "farm": "A charming barnyard celebration",
  "football": "Score big on your birthday",
  "cricket": "Hit it out of the park",
  "unicorn": "A magical rainbow birthday dream",
  "mermaid": "Dive into an ocean adventure",
  "butterfly": "Flutter into a garden birthday",
  "rainbow": "Celebrate in every color",
  "candyland": "The sweetest birthday ever",
  "princess": "Every girl is royalty today",
  "barbie": "Fabulous, fun and full of pink",
  "frozen": "Let it go and celebrate",
  "minnie-mouse": "Oh Toodles! Party time!",
  "peppa-pig": "Muddy puddles & birthday fun",
};

function getThemeImage(themeId: string): string {
  return themeImages[themeId] ?? pkgKids;
}

const boyThemes = kidsThemes.filter((t) => t.category === "boys");
const girlThemes = kidsThemes.filter((t) => t.category === "girls");

export function KidsThemesPage() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <SiteHeader active="Kids Themes" />

      {/* Hero */}
      <section className="relative bg-gradient-hero text-white overflow-hidden">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage:
              "radial-gradient(circle at 15% 25%, oklch(0.65 0.24 350 / 0.55), transparent 40%), radial-gradient(circle at 85% 65%, oklch(0.82 0.15 85 / 0.45), transparent 42%)",
          }}
        />
        <div className="mx-auto max-w-7xl px-4 py-20 md:py-28 text-center relative">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-script text-5xl md:text-6xl text-[color:var(--gold)] drop-shadow"
          >
            Kids Theme Decoration
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="font-display italic text-3xl md:text-5xl tracking-tight mt-3 leading-tight"
          >
            Choose Your Dream Birthday Theme
          </motion.h1>
          <div className="flex items-center justify-center gap-3 mt-5">
            <span className="h-px w-16 bg-[color:var(--gold)]/70" />
            <SparkleIcon className="w-4 h-4 text-[color:var(--gold)]" />
            <span className="h-px w-16 bg-[color:var(--gold)]/70" />
          </div>
          <p className="mt-5 max-w-2xl mx-auto text-white/85 text-base md:text-lg font-light">
            From superheroes to magical unicorns, pick a theme below and explore our stunning decoration packages crafted to make your child's birthday unforgettable.
          </p>
        </div>
      </section>

      <main className="py-16 md:py-24 bg-gradient-soft">
        <div className="mx-auto max-w-7xl px-4">

          {/* Boy's Themes */}
          <div className="mb-16">
            <div className="text-center mb-10">
              <p className="font-script text-3xl text-[color:var(--pink)]">For the Little Heroes</p>
              <h2 className="font-display italic text-3xl md:text-4xl text-[color:var(--purple-deep)] mt-1">
                Boy's Theme Decorations
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {boyThemes.map((theme, index) => (
                <ThemeCard
                  key={theme.id}
                  id={theme.id}
                  title={theme.title}
                  image={getThemeImage(theme.id)}
                  tagline={themeTaglines[theme.id] ?? "Exciting themed birthday packages"}
                  index={index}
                />
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-4 mb-16">
            <span className="flex-1 h-px bg-border" />
            <SparkleIcon className="w-5 h-5 text-[color:var(--gold)]" />
            <span className="flex-1 h-px bg-border" />
          </div>

          {/* Girl's Themes */}
          <div>
            <div className="text-center mb-10">
              <p className="font-script text-3xl text-[color:var(--pink)]">For the Little Princesses</p>
              <h2 className="font-display italic text-3xl md:text-4xl text-[color:var(--purple-deep)] mt-1">
                Girl's Theme Decorations
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {girlThemes.map((theme, index) => (
                <ThemeCard
                  key={theme.id}
                  id={theme.id}
                  title={theme.title}
                  image={getThemeImage(theme.id)}
                  tagline={themeTaglines[theme.id] ?? "Magical themed birthday packages"}
                  index={index}
                />
              ))}
            </div>
          </div>

          {/* Back to Home */}
          <div className="mt-16 text-center">
            <Link
              href="/"
              className="inline-flex items-center gap-2 rounded-full px-6 py-3 border border-[color:var(--gold)]/50 text-[color:var(--purple-deep)] font-semibold text-sm hover:bg-[color:var(--gold)]/10 transition-colors"
            >
              ← Back to Home
            </Link>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}

function ThemeCard({
  id,
  title,
  image,
  tagline,
  index,
}: {
  id: string;
  title: string;
  image: string;
  tagline: string;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay: (index % 4) * 0.06, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -8 }}
      className="group"
    >
      <Link
        href={`/kids-themes/${id}`}
        className="block rounded-2xl overflow-hidden bg-white shadow-card border border-border/70 hover:border-[color:var(--gold)]/60 transition-colors"
      >
        {/* Image */}
        <div className="aspect-[4/3] overflow-hidden relative">
          <img
            src={image}
            alt={title}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[color:var(--purple-deep)]/80 via-[color:var(--purple-deep)]/10 to-transparent" />
          <div className="absolute bottom-3 left-3 right-3 text-white">
            <h3 className="font-display italic text-xl leading-tight">{title}</h3>
            <p className="text-white/75 text-xs mt-0.5 line-clamp-1">{tagline}</p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">4 packages available</span>
          <span className="inline-flex items-center gap-1 text-xs font-bold text-[color:var(--pink)] uppercase tracking-widest">
            View Packages
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
          </span>
        </div>
      </Link>
    </motion.div>
  );
}
