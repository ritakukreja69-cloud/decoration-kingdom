import { Link } from "wouter";
import { motion, useReducedMotion, type Variants } from "framer-motion";
import {
  Facebook, Instagram, MessageCircle, Send, ArrowRight, Phone,
  PartyPopper, Lightbulb, Users, Truck, Package, BadgeCheck, Shield,
  Trophy, Smile, MapPin, Heart, Mail, Menu, X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import heroImg from "@/assets/hero-birthday.jpg";
import specBirthday from "@/assets/spec-birthday.jpg";
import { WHATSAPP_BOOKING_URL } from "@/lib/whatsapp";
import specWedding from "@/assets/spec-wedding.jpg";
import specCorporate from "@/assets/spec-corporate.jpg";
import specBaby from "@/assets/spec-baby.jpg";
import specTheme from "@/assets/spec-theme.jpg";
import specProposal from "@/assets/spec-proposal.jpg";
import pkgKids from "@/assets/pkg-kids.jpg";
import g1 from "@/assets/recent-1.png";
import g2 from "@/assets/recent-2.png";
import g3 from "@/assets/recent-3.png";
import g4 from "@/assets/recent-4.png";
import g5 from "@/assets/recent-5.png";
import g6 from "@/assets/recent-6.png";
import celebRomantic from "@/assets/celeb-romantic-date.jpg";
import celebProposal from "@/assets/celeb-proposal.jpg";

import celebAnniversary from "@/assets/celeb-anniversary.jpg";
import celebBabyShower from "@/assets/celeb-babyshower.jpg";
import celebBabyWelcome from "@/assets/celeb-babywelcome.jpg";
import celebNaming from "@/assets/celeb-naming.jpg";
import celebCar from "@/assets/celeb-car.jpg";
import { categories as collectionCategories } from "@/lib/packages-catalog";
import { CollectionBanner } from "@/components/packages/CollectionBanner";

const romanticCelebrations = [
  { title: "Romantic Dates", img: celebRomantic, to: "/packages", hash: "anniversary" },
  { title: "Proposal", img: celebProposal, to: "/packages", hash: "ring" },
  { title: "Anniversary Decoration", img: celebAnniversary, to: "/packages", hash: "anniversary" },
];

const babyCelebrations = [
  { title: "Baby Shower", img: celebBabyShower, to: "/packages", hash: "baby-shower" },
  { title: "Baby Welcome", img: celebBabyWelcome, to: "/packages", hash: "welcome-baby" },
  { title: "Naming Ceremony", img: celebNaming, to: "/packages", hash: "welcome-baby" },
  { title: "Kids Themes", img: pkgKids, to: "/kids-themes" },
];

const navItems = [
  { label: "Home", to: "/" },
  { label: "About Us", to: "/about" },
  { label: "Services", to: "/", hash: "services" },
  { label: "Gallery", to: "/", hash: "gallery" },
  { label: "Packages", to: "/packages" },
  { label: "Blog", to: "/blog" },
  { label: "Contact Us", to: "/", hash: "contact" },
];

const features = [
  { icon: PartyPopper, label: "Balloons\nof All Types" },
  { icon: Lightbulb, label: "Creative & Unique\nDecor Ideas" },
  { icon: Users, label: "Professional\nTeam" },
  { icon: Truck, label: "On-Time\nDelivery" },
  { icon: Package, label: "Affordable\nPackages" },
  { icon: Shield, label: "Premium Quality\nAssurance" },
];

const specialties = [
  { title: "Birthday Decoration", img: specBirthday, to: "/packages/collection/birthday" },
  { title: "Anniversary Decoration", img: celebAnniversary, to: "/packages/collection/anniversary" },
  { title: "Baby Shower Decoration", img: specBaby, to: "/packages/collection/baby-shower" },
  { title: "Welcome Baby Decoration", img: celebBabyWelcome, to: "/packages/collection/welcome-baby" },
  { title: "Proposal Decoration", img: celebProposal, to: "/packages/collection/proposal" },
  { title: "Haldi Decoration", img: specWedding, to: "/packages/collection/haldi" },
  { title: "Mehendi Decoration", img: celebNaming, to: "/packages/collection/mehendi" },
  { title: "Engagement Decoration", img: specWedding, to: "/packages/collection/engagement" },
  { title: "Corporate Event Decoration", img: specCorporate, to: "/packages/collection/corporate" },
  { title: "Kids Theme Decoration", img: specTheme, to: "/kids-themes" },
];

const stats = [
  { icon: Trophy, value: "500+", label: "Successful Events" },
  { icon: Smile, value: "100%", label: "Client Satisfaction" },
  { icon: PartyPopper, value: "10+", label: "Years Experience" },
  { icon: MapPin, value: "2 Cities", label: "Serving in Delhi & NCR" },
];

const gallery = [g1, g2, g3, g4, g5, g6];

/* Decorative floating balloon */
function Balloon({ className, color, delay = 0 }: { className?: string; color: string; delay?: number }) {
  return (
    <motion.div
      className={`absolute pointer-events-none ${className ?? ""}`}
      animate={{ y: [0, -20, 0], rotate: [-3, 3, -3] }}
      transition={{ duration: 6 + delay, repeat: Infinity, ease: "easeInOut", delay }}
      aria-hidden
    >
      <div
        className="w-14 h-16 rounded-full relative"
        style={{
          background: `radial-gradient(circle at 30% 30%, oklch(0.95 0.05 350 / 0.9), ${color})`,
          boxShadow: `inset -6px -8px 14px oklch(0 0 0 / 0.15), 0 8px 20px oklch(0 0 0 / 0.15)`,
        }}
      >
        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rotate-45" style={{ background: color }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 w-px h-24 bg-foreground/20" />
      </div>
    </motion.div>
  );
}

function Sparkles({ className }: { className?: string }) {
  return (
    <div className={`absolute pointer-events-none ${className ?? ""}`} aria-hidden>
      {Array.from({ length: 12 }).map((_, i) => (
        <motion.span
          key={i}
          className="absolute block w-1.5 h-1.5 rounded-sm"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: i % 2 === 0 ? "var(--gold)" : "var(--pink)",
            transform: "rotate(45deg)",
          }}
          animate={{ opacity: [0.2, 1, 0.2], scale: [0.6, 1.2, 0.6] }}
          transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}
        />
      ))}
    </div>
  );
}

/* Confetti burst — a one-shot party-popper explosion */
function ConfettiBurst({ count = 60 }: { count?: number }) {
  const reduce = useReducedMotion();
  const pieces = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => {
        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.4;
        const distance = 220 + Math.random() * 260;
        const colors = [
          "oklch(0.65 0.24 350)", "oklch(0.5 0.22 300)", "oklch(0.82 0.15 85)",
          "oklch(0.7 0.18 60)", "oklch(0.75 0.18 300)", "oklch(0.55 0.24 340)",
        ];
        return {
          x: Math.cos(angle) * distance,
          y: Math.sin(angle) * distance - 40,
          rot: Math.random() * 720 - 360,
          color: colors[i % colors.length],
          size: 6 + Math.random() * 8,
          shape: i % 3,
          delay: Math.random() * 0.15,
        };
      }),
    [count],
  );
  if (reduce) return null;
  return (
    <div className="absolute inset-0 pointer-events-none overflow-visible" aria-hidden>
      <div className="absolute left-1/2 top-1/2">
        {pieces.map((p, i) => (
          <motion.span
            key={i}
            className="absolute block"
            style={{
              width: p.size,
              height: p.shape === 1 ? p.size * 0.5 : p.size,
              background: p.color,
              borderRadius: p.shape === 2 ? "9999px" : p.shape === 1 ? "2px" : "0",
              left: 0, top: 0,
            }}
            initial={{ x: 0, y: 0, rotate: 0, opacity: 1, scale: 0 }}
            animate={{ x: p.x, y: p.y, rotate: p.rot, opacity: [1, 1, 0], scale: [0, 1, 0.8] }}
            transition={{ duration: 1.6, delay: p.delay, ease: [0.16, 1, 0.3, 1] }}
          />
        ))}
      </div>
    </div>
  );
}

/* Section wrapper: fade + slide on scroll into view */
function Reveal({
  children, delay = 0, y = 30, className,
}: { children: React.ReactNode; delay?: number; y?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function ThemedCollection({
  eyebrow, title, highlight, subtitle, items, bg,
}: {
  eyebrow: string; title: string; highlight: string; subtitle?: string;
  items: { title: string; img: string; to: string; hash?: string }[]; bg?: string;
}) {
  
  return (
    <section className={`py-16 md:py-20 relative overflow-hidden ${bg ?? ""}`}>
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center mb-10">
          <p className="font-script text-3xl md:text-5xl text-[color:var(--pink)]">{eyebrow}</p>
          <h2 className="font-display font-black text-3xl md:text-4xl text-[color:var(--purple-deep)] tracking-tight mt-1">
            {title} <span className="text-[color:var(--pink)]">{highlight}</span>
          </h2>
          <div className="flex items-center justify-center gap-2 mt-3">
            <span className="h-px w-14 bg-[color:var(--pink)]" />
            <Heart className="w-4 h-4 text-[color:var(--pink)] fill-current" />
            <span className="h-px w-14 bg-[color:var(--pink)]" />
          </div>
          {subtitle && <p className="mt-4 max-w-2xl mx-auto text-muted-foreground text-sm md:text-base">{subtitle}</p>}
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {items.map((it, i) => (
            <motion.a
              key={it.title}
              href={it.hash ? `${it.to === "/" ? "" : it.to}/#${it.hash}` : it.to}
              initial={{ opacity: 0, y: 40, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -8 }}
              className="group relative rounded-[2rem] overflow-hidden shadow-card bg-white block"
            >
              <div className="absolute -top-3 -right-3 z-10 w-10 h-10 rotate-12 pointer-events-none">
                <Heart className="w-10 h-10 text-[color:var(--pink)] fill-current drop-shadow-lg" />
              </div>
              <div className="aspect-[4/5] overflow-hidden">
                <img
                  src={it.img} alt={it.title} loading="lazy" width={800} height={1000}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
              </div>
              <div className="absolute inset-x-0 bottom-0 p-4 pt-14 bg-gradient-to-t from-[color:var(--purple-deep)]/95 via-[color:var(--purple-deep)]/60 to-transparent">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-display font-bold text-white text-sm md:text-base tracking-wide">{it.title}</h3>
                  <span className="w-8 h-8 grid place-items-center rounded-full bg-gradient-primary text-white shadow-pink shrink-0">
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}

export function HomePage() {
  const [open, setOpen] = useState(false);
  const [burst, setBurst] = useState(0);
  useEffect(() => { setBurst(1); }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Top bar */}
      <div className="bg-gradient-topbar text-white text-sm">
        <div className="mx-auto max-w-7xl px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-[color:var(--pink)] fill-current" />
            <span className="hidden sm:inline">Welcome to Decoration Kingdom – We Decorate Your Moments!</span>
            <span className="sm:hidden">Welcome to Decoration Kingdom</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline">Follow Us :</span>
            <a href="#" aria-label="Facebook" className="w-7 h-7 rounded-full bg-white/95 text-[color:var(--purple-deep)] grid place-items-center hover:scale-110 transition-transform">
              <Facebook className="w-4 h-4" />
            </a>
            <a href="https://www.instagram.com/decorationkingdomdelhincr?utm_source=qr&igsh=NHp0bHZvZmM2dmd1" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="w-7 h-7 rounded-full bg-white/95 text-[color:var(--pink)] grid place-items-center hover:scale-110 transition-transform">
              <Instagram className="w-4 h-4" />
            </a>
            <a href={WHATSAPP_BOOKING_URL} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="w-7 h-7 rounded-full bg-[#25D366] text-white grid place-items-center hover:scale-110 transition-transform">
              <MessageCircle className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>

      {/* Nav */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-border">
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between gap-4">
          <a href="/" className="flex items-center gap-3">
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="relative w-16 h-16 rounded-2xl overflow-hidden bg-white/90 shadow-lg"
              aria-hidden
            >
              <img src="/logo.svg" alt="Decoration Kingdom logo" className="h-full w-full object-contain p-2" />
            </motion.div>
            <div className="leading-tight">
              <div className="font-display font-black text-xl tracking-tight text-[color:var(--purple-deep)]">Decoration Kingdom</div>
              <div className="text-xs uppercase tracking-[0.28em] text-[color:var(--pink)] font-semibold">Celebrations</div>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-7">
            {navItems.map((item, i) => {
              const isAnchor = item.to === "/" && item.hash;
              const commonClasses = `text-sm font-semibold tracking-wide uppercase transition-colors relative py-2 ${
                i === 0 ? "text-[color:var(--pink)]" : "text-[color:var(--purple-deep)] hover:text-[color:var(--pink)]"
              }`;

              return isAnchor ? (
                <a key={item.label} href={`/${item.to === "/" ? "" : item.to}#${item.hash}`} className={commonClasses}>
                  {item.label}
                </a>
              ) : (
                <Link key={item.label} href={item.to} className={commonClasses}>
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              href={WHATSAPP_BOOKING_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:inline-flex items-center gap-2 rounded-full px-5 py-3 text-white font-semibold text-sm bg-gradient-primary shadow-pink"
            >
              GET A QUOTE
              <span className="w-6 h-6 grid place-items-center rounded-full bg-white/20">
                <Send className="w-3.5 h-3.5" />
              </span>
            </motion.a>
            <button
              onClick={() => setOpen((v) => !v)}
              className="lg:hidden p-2 rounded-md text-[color:var(--purple-deep)]"
              aria-label="Toggle menu"
            >
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        {open && (
          <div className="lg:hidden border-t border-border bg-white">
            <nav className="px-4 py-3 flex flex-col gap-1">
              {navItems.map((item) => {
                const isAnchor = item.to === "/" && item.hash;
                return isAnchor ? (
                  <a key={item.label} href={`/#${item.hash}`} className="py-2 text-sm font-semibold text-[color:var(--purple-deep)]">
                    {item.label}
                  </a>
              ) : (
                  <Link key={item.label} href={item.to} className="py-2 text-sm font-semibold text-[color:var(--purple-deep)]">
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="relative bg-gradient-soft overflow-hidden" style={{ perspective: 1400 }}>
        <Sparkles className="inset-0" />
        <Balloon className="top-20 left-4 hidden md:block" color="oklch(0.55 0.24 340)" delay={0} />
        <Balloon className="top-40 left-24 hidden md:block" color="oklch(0.7 0.18 60)" delay={1.2} />
        <Balloon className="bottom-10 left-10 hidden md:block" color="oklch(0.5 0.22 300)" delay={0.6} />

        <div className="mx-auto max-w-7xl px-4 py-12 md:py-16 grid lg:grid-cols-2 gap-10 items-center relative">
          <motion.div
            initial="hidden"
            animate="show"
            variants={{
              hidden: {},
              show: { transition: { staggerChildren: 0.09, delayChildren: 0.1 } },
            }}
            className="relative z-10"
            style={{ transformStyle: "preserve-3d" }}
          >
            <motion.p
              variants={{
                hidden: { opacity: 0, y: 20, rotateX: -30 },
                show: { opacity: 1, y: 0, rotateX: 0, transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] } },
              }}
              className="font-script text-4xl md:text-5xl text-[color:var(--pink)] mb-2"
              style={{ transformOrigin: "left bottom" }}
            >
              We Decorate
            </motion.p>
            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl leading-[1.05] tracking-tight">
              {["YOUR MOMENTS,", "YOU CHERISH", "FOREVER!"].map((line, i) => (
                <motion.span
                  key={line}
                  variants={{
                    hidden: { opacity: 0, y: 40, rotateX: -60, filter: "blur(6px)" },
                    show: {
                      opacity: 1, y: 0, rotateX: 0, filter: "blur(0px)",
                      transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] },
                    },
                  }}
                  className={`block ${i === 2 ? "text-gradient-primary" : "text-[color:var(--purple-deep)]"}`}
                  style={{ transformOrigin: "left bottom", transformStyle: "preserve-3d" }}
                >
                  {line}
                </motion.span>
              ))}
            </h1>
            <motion.div
              variants={{ hidden: { opacity: 0, scaleX: 0 }, show: { opacity: 1, scaleX: 1, transition: { duration: 0.6 } } }}
              className="flex items-center gap-2 mt-4 origin-left"
            >
              <span className="h-px w-16 bg-[color:var(--pink)]" />
              <Heart className="w-4 h-4 text-[color:var(--pink)] fill-current" />
              <span className="h-px w-16 bg-[color:var(--pink)]" />
            </motion.div>
            <motion.p
              variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { duration: 0.7 } } }}
              className="mt-5 text-muted-foreground max-w-md leading-relaxed"
            >
              From birthdays to weddings, we bring your dream celebrations to life with beautiful balloon decorations.
            </motion.p>
            <motion.div
              variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { duration: 0.7 } } }}
              className="mt-8 flex flex-wrap gap-4"
            >
              <Link
                href="/services"
                className="inline-flex items-center gap-3 rounded-full pl-6 pr-2 py-2 text-white font-bold text-sm bg-gradient-primary shadow-pink hover:scale-105 transition-transform"
              >
                OUR SERVICES
                <span className="w-9 h-9 grid place-items-center rounded-full bg-white/25">
                  <ArrowRight className="w-4 h-4" />
                </span>
              </Link>
              <a
                href="/gallery"
                className="inline-flex items-center gap-3 rounded-full pl-6 pr-2 py-2 text-[color:var(--purple-deep)] font-bold text-sm border-2 border-[color:var(--purple-deep)]/20 bg-white hover:scale-105 transition-transform"
              >
                VIEW GALLERY
                <span className="w-9 h-9 grid place-items-center rounded-full bg-gradient-primary text-white">
                  <ArrowRight className="w-4 h-4" />
                </span>
              </a>
              </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.7, rotateY: -35, rotateX: 12, y: 40 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0, rotateX: 0, y: 0 }}
            transition={{ duration: 1.1, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
            whileHover={{ rotateY: 6, rotateX: -4, scale: 1.02 }}
            className="relative"
            style={{ transformStyle: "preserve-3d", transformPerspective: 1400 }}
          >
            {burst > 0 && <ConfettiBurst />}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="relative rounded-[2.5rem] overflow-hidden shadow-glow"
              style={{ transformStyle: "preserve-3d" }}
            >
              <img
                src={heroImg}
                alt="Balloon birthday decoration setup"
                width={1280} height={960}
                className="w-full h-[420px] md:h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-[color:var(--purple-deep)]/25 via-transparent to-transparent" />
              <motion.div
                initial={{ x: "-120%" }}
                animate={{ x: "120%" }}
                transition={{ duration: 1.6, delay: 0.9, ease: "easeOut" }}
                className="absolute inset-y-0 w-1/3 skew-x-[-20deg]"
                style={{ background: "linear-gradient(90deg, transparent, oklch(1 0 0 / 0.35), transparent)" }}
              />
            </motion.div>
            <motion.div
              animate={{ y: [0, -14, 0], rotate: [-4, 4, -4] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-6 -left-4 w-16 h-20 rounded-full hidden md:block"
              style={{
                background: "radial-gradient(circle at 30% 30%, oklch(0.9 0.05 90), oklch(0.75 0.15 60))",
                transform: "translateZ(60px)",
              }}
              aria-hidden
            />
            <motion.div
              animate={{ y: [0, 12, 0], rotate: [3, -3, 3] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 0.8 }}
              className="absolute -bottom-4 -right-2 w-14 h-16 rounded-full hidden md:block"
              style={{
                background: "radial-gradient(circle at 30% 30%, oklch(0.85 0.15 350), oklch(0.55 0.24 340))",
                transform: "translateZ(80px)",
              }}
              aria-hidden
            />
          </motion.div>
        </div>


        {/* Features strip */}
        <div className="mx-auto max-w-7xl px-4 pb-12 relative">
          <div className="bg-white rounded-3xl shadow-card px-4 md:px-8 py-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="flex flex-col items-center text-center group"
              >
                <div className="w-14 h-14 rounded-2xl grid place-items-center text-[color:var(--pink)] group-hover:scale-110 transition-transform">
                  <f.icon className="w-8 h-8" strokeWidth={1.5} />
                </div>
                <div className="mt-2 text-xs font-bold tracking-wide uppercase text-[color:var(--purple-deep)] whitespace-pre-line">
                  {f.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* SPECIALTIES */}
      <section id="services" className="py-16 md:py-20 relative">
        <div className="mx-auto max-w-7xl px-4">
          <div className="text-center mb-12">
            <p className="font-script text-4xl md:text-5xl text-[color:var(--pink)]">Our Specialties</p>
            <h2 className="font-display font-black text-3xl md:text-4xl text-[color:var(--purple-deep)] tracking-tight mt-1">
              DECORATIONS <span className="text-[color:var(--pink)]">FOR EVERY OCCASION</span>
            </h2>
            <div className="flex items-center justify-center gap-2 mt-3">
              <span className="h-px w-14 bg-[color:var(--pink)]" />
              <Heart className="w-4 h-4 text-[color:var(--pink)] fill-current" />
              <span className="h-px w-14 bg-[color:var(--pink)]" />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-5">
            {specialties.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: i * 0.06 }}
                whileHover={{ y: -6 }}
                className="bg-white rounded-2xl overflow-hidden shadow-card group"
              >
                <a href={s.to} className="block">
                  <div className="overflow-hidden">
                    <img
                      src={s.img} alt={s.title} loading="lazy" width={640} height={640}
                      className="w-full aspect-square object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="px-3 py-4 text-center">
                    <h3 className="text-xs md:text-sm font-bold uppercase text-[color:var(--purple-deep)] leading-tight">{s.title}</h3>
                    <div className="mt-3 mx-auto w-8 h-8 grid place-items-center rounded-full bg-gradient-primary text-white shadow-pink group-hover:rotate-45 transition-transform">
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </a>
              </motion.div>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link
              href="/packages"
              className="inline-flex items-center gap-3 rounded-full pl-6 pr-2 py-2 bg-gradient-band text-white font-bold text-sm hover:scale-105 transition-transform"
            >
              VIEW ALL SERVICES
              <span className="w-9 h-9 grid place-items-center rounded-full bg-gradient-primary">
                <ArrowRight className="w-4 h-4" />
              </span>
            </Link>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="relative bg-gradient-band text-white py-10 overflow-hidden">
        <Balloon className="top-2 left-4 hidden md:block" color="oklch(0.85 0.12 90)" delay={0} />
        <Balloon className="bottom-2 right-6 hidden md:block" color="oklch(0.65 0.24 350)" delay={1.5} />
        <div className="mx-auto max-w-7xl px-4 grid grid-cols-2 md:grid-cols-4 gap-6 relative">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-3 justify-center md:justify-start"
            >
              <div className="w-12 h-12 rounded-full grid place-items-center bg-white/10 text-[color:var(--gold)]">
                <s.icon className="w-6 h-6" />
              </div>
              <div>
                <div className="font-display font-black text-2xl md:text-3xl text-[color:var(--gold)]">{s.value}</div>
                <div className="text-xs md:text-sm text-white/80">{s.label}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* BABY CELEBRATIONS */}
      <ThemedCollection
        eyebrow="Little Wonders"
        title="Baby"
        highlight="Celebrations"
        subtitle="Dreamy pastel setups to welcome your little star into the world."
        items={babyCelebrations}
        bg="bg-gradient-soft"
      />

      {/* GALLERY */}
      <section id="gallery" className="py-16 md:py-20 bg-gradient-soft">
        <div className="mx-auto max-w-7xl px-4">
          <div className="text-center mb-12">
            <p className="font-script text-4xl md:text-5xl text-[color:var(--pink)]">Our Recent Work</p>
            <h2 className="font-display font-black text-3xl md:text-4xl text-[color:var(--purple-deep)] tracking-tight mt-1">
              MAKING MOMENTS <span className="text-[color:var(--pink)]">MAGICAL</span>
            </h2>
            <div className="flex items-center justify-center gap-2 mt-3">
              <span className="h-px w-14 bg-[color:var(--pink)]" />
              <Heart className="w-4 h-4 text-[color:var(--pink)] fill-current" />
              <span className="h-px w-14 bg-[color:var(--pink)]" />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {gallery.map((img, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                whileHover={{ scale: 1.03 }}
                className="rounded-2xl overflow-hidden shadow-card"
              >
                <img src={img} alt={`Recent work ${i + 1}`} loading="lazy" width={640} height={512}
                  className="w-full aspect-[5/4] object-cover" />
              </motion.div>
            ))}
          </div>

          <div className="mt-10 text-center">
            <a
                href="/gallery"
              className="inline-flex items-center gap-3 rounded-full pl-6 pr-2 py-2 bg-gradient-primary text-white font-bold text-sm shadow-pink hover:scale-105 transition-transform"
            >
              VIEW FULL GALLERY
              <span className="w-9 h-9 grid place-items-center rounded-full bg-white/20">
                <ArrowRight className="w-4 h-4" />
              </span>
            </a>
          </div>
        </div>
      </section>

      {/* CONTACT BAND */}
      <section id="contact" className="bg-gradient-band text-white py-10">
        <div className="mx-auto max-w-7xl px-4 grid md:grid-cols-4 gap-6 items-center">
          <div>
            <p className="font-script text-3xl text-[color:var(--pink)]">Let's Make Your Event</p>
            <h3 className="font-display font-black text-2xl tracking-tight">UNFORGETTABLE!</h3>
            <div className="flex items-center gap-2 mt-2">
              <span className="h-px w-10 bg-[color:var(--pink)]" />
              <Heart className="w-3 h-3 text-[color:var(--pink)] fill-current" />
              <span className="h-px w-10 bg-[color:var(--pink)]" />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-full bg-gradient-primary grid place-items-center animate-pulse-ring">
                <Phone className="w-5 h-5" />
              </div>
            </div>
            <div className="text-sm">
              <div className="text-white/70">Call Us Now</div>
              <div className="font-bold text-[color:var(--gold)]">9310854642</div>
              <div className="font-bold text-[color:var(--gold)]">9971265244</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#25D366] grid place-items-center animate-pulse-ring">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div className="text-sm">
              <div className="text-white/70">WhatsApp Us</div>
              <div className="font-bold">Quick Reply</div>
              <div className="font-bold">on WhatsApp</div>
            </div>
          </div>

          <div className="flex flex-col items-start md:items-end">
            <a
              href={WHATSAPP_BOOKING_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 rounded-full pl-6 pr-2 py-2 bg-gradient-primary text-white font-bold text-sm shadow-pink hover:scale-105 transition-transform"
            >
              GET A FREE QUOTE
              <span className="w-9 h-9 grid place-items-center rounded-full bg-white/25">
                <ArrowRight className="w-4 h-4" />
              </span>
            </a>
            <p className="text-xs text-white/70 mt-2">We'll get back to you!</p>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[color:var(--purple-deep)] text-white/90 py-10">
        <div className="mx-auto max-w-7xl px-4 grid md:grid-cols-4 gap-8 text-sm">
          <div>
            <div className="font-display font-black text-xl">DECORATION KINGDOM</div>
            <div className="text-[10px] tracking-[0.4em] text-[color:var(--pink)] font-semibold">CELEBRATIONS</div>
            <p className="mt-3 text-white/70 leading-relaxed">
              We bring imagination to life with beautiful balloon decorations for every celebration.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-3">Quick Links</h4>
            <ul className="space-y-2 text-white/70">
              {["Home","About Us","Services","Gallery","Packages","Blog","Contact Us"].map(l => (
                <li key={l}><a href="#" className="hover:text-[color:var(--pink)]">{l}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-3">Contact Info</h4>
            <ul className="space-y-2 text-white/70">
              <li className="flex items-center gap-2"><Mail className="w-4 h-4 text-[color:var(--pink)]" /> support@decorationkingdom.com</li>
              <li className="flex items-center gap-2"><BadgeCheck className="w-4 h-4 text-[color:var(--pink)]" /> decorationkingdom.com</li>
              <li className="flex items-center gap-2"><MapPin className="w-4 h-4 text-[color:var(--pink)]" /> Delhi & NCR</li>
              <li className="flex items-center gap-2"><Phone className="w-4 h-4 text-[color:var(--pink)]" /> 9310854642</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-3">Follow Us</h4>
            <div className="flex gap-3">
              <a href="#" aria-label="Facebook" className="w-9 h-9 rounded-full bg-white/10 grid place-items-center hover:bg-[color:var(--pink)] transition-colors"><Facebook className="w-4 h-4" /></a>
              <a href="https://www.instagram.com/decorationkingdomdelhincr?utm_source=qr&igsh=NHp0bHZvZmM2dmd1" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="w-9 h-9 rounded-full bg-white/10 grid place-items-center hover:bg-[color:var(--pink)] transition-colors"><Instagram className="w-4 h-4" /></a>
              <a href="https://wa.me/919310854642" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="w-9 h-9 rounded-full bg-white/10 grid place-items-center hover:bg-[#25D366] transition-colors"><MessageCircle className="w-4 h-4" /></a>
            </div>
          </div>
        </div>
        <div className="mx-auto max-w-7xl px-4 mt-8 pt-4 border-t border-white/10 text-xs text-white/50 text-center">
          © {new Date().getFullYear()} Decoration Kingdom. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
