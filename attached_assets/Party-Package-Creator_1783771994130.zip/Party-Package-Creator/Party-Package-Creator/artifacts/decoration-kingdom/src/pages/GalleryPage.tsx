import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useMemo, useState } from "react";
import { X, ArrowRight, Camera } from "lucide-react";

import { SiteHeader, SiteFooter } from "@/components/site-chrome";
import { allPackages } from "@/lib/packages-data";

const filters = [
  { id: "all", label: "All" },
  { id: "birthday", label: "Birthday" },
  { id: "anniversary", label: "Anniversary" },
  { id: "kids", label: "Kids" },
  { id: "welcome-baby", label: "Welcome Baby" },
  { id: "baby-shower", label: "Baby Shower" },
  { id: "ring", label: "Ring & Proposal" },
];

export function GalleryPage() {
  const [filter, setFilter] = useState<string>("all");
  const [lightbox, setLightbox] = useState<string | null>(null);

  const items = useMemo(() => {
    const source = filter === "all" ? allPackages : allPackages.filter((p) => p.sectionId === filter);
    // dedupe on img to keep the grid visually varied
    const seen = new Set<string>();
    return source.filter((p) => (seen.has(p.img) ? false : (seen.add(p.img), true)));
  }, [filter]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <SiteHeader active="Gallery" />

      <section className="relative bg-gradient-hero text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25"
          style={{ backgroundImage: "radial-gradient(circle at 15% 25%, oklch(0.65 0.24 350 / 0.55), transparent 40%), radial-gradient(circle at 85% 65%, oklch(0.82 0.15 85 / 0.45), transparent 42%)" }} />
        <div className="mx-auto max-w-7xl px-4 py-20 md:py-24 text-center relative">
          <p className="font-script text-5xl md:text-6xl text-[color:var(--gold)]">Our Work</p>
          <h1 className="font-display italic text-4xl md:text-6xl mt-3">
            Real setups, <span className="text-[color:var(--gold)]">real celebrations</span>
          </h1>
          <p className="mt-5 max-w-2xl mx-auto text-white/85 font-light">
            Every photograph is a home we transformed across Delhi NCR.
          </p>
        </div>
      </section>

      {/* Filters */}
      <div className="sticky top-16 z-30 bg-white/95 backdrop-blur border-b border-border">
        <div className="mx-auto max-w-7xl px-4 py-3 flex gap-2 overflow-x-auto">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-widest border transition ${
                filter === f.id
                  ? "bg-gradient-primary text-white border-transparent shadow-pink"
                  : "bg-white text-[color:var(--purple-deep)] border-border hover:border-[color:var(--pink)]"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Masonry-ish grid */}
      <section className="py-14 md:py-20 bg-gradient-soft">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {items.map((p, i) => (
              <motion.button
                key={p.slug}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: (i % 8) * 0.04 }}
                onClick={() => setLightbox(p.img)}
                className={`group relative overflow-hidden rounded-2xl shadow-card border border-border/70 bg-white ${
                  i % 7 === 0 ? "row-span-2 aspect-[3/5]" : "aspect-square"
                }`}
              >
                <img src={p.img} alt={p.title} loading="lazy" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute left-3 right-3 bottom-3 text-white text-left opacity-0 group-hover:opacity-100 transition-opacity">
                  <p className="text-[10px] uppercase tracking-widest text-[color:var(--gold)]">{p.eyebrow}</p>
                  <p className="font-display italic text-sm line-clamp-2">{p.title}</p>
                </div>
              </motion.button>
            ))}
          </div>

          {items.length === 0 && (
            <div className="text-center py-16 text-muted-foreground">
              <Camera className="w-8 h-8 mx-auto mb-3" />
              No photos in this category yet.
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-band text-white py-14">
        <div className="mx-auto max-w-7xl px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <p className="font-script text-4xl text-[color:var(--gold)]">Loved something?</p>
            <h3 className="font-display italic text-2xl md:text-3xl">Recreate it for your event</h3>
          </div>
          <Link href="/packages" className="inline-flex items-center gap-2 rounded-full px-6 py-3 bg-gradient-primary text-white font-bold text-sm shadow-pink">
            View Packages <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 grid place-items-center p-4"
            onClick={() => setLightbox(null)}
          >
            <button
              onClick={() => setLightbox(null)}
              aria-label="Close"
              className="absolute top-4 right-4 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 text-white grid place-items-center"
            >
              <X className="w-5 h-5" />
            </button>
            <motion.img
              key={lightbox}
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
              src={lightbox}
              alt=""
              className="max-h-[85vh] max-w-[92vw] rounded-2xl shadow-2xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <SiteFooter />
    </div>
  );
}
