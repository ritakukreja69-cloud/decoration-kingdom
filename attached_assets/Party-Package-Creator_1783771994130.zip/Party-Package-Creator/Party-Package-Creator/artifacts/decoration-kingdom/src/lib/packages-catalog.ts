/**
 * ─────────────────────────────────────────────────────────────────────────
 * CENTRAL PACKAGE + PRICE DATA SOURCE
 * ─────────────────────────────────────────────────────────────────────────
 * Every collection page, sub-collection page and the package modal reads
 * from this single file. To change a price, description, inclusion list,
 * duration, area or add-on — edit it ONCE here and it updates everywhere.
 *
 * Images are auto-loaded from `src/assets/pkg/<category>/<subcategory>/*`
 * (or `src/assets/pkg/<category>/_/*` for categories with no subcategory),
 * so dropping a new photo into the right folder automatically creates a
 * new package card — no code changes required.
 * ─────────────────────────────────────────────────────────────────────────
 */

export type CategoryId =
  | "birthday"
  | "anniversary"
  | "proposal"
  | "baby-shower"
  | "naming-ceremony"
  | "haldi"
  | "mehendi"
  | "ring-ceremony";

export type SubcategoryDef = { id: string; label: string };

export type CategoryDef = {
  id: CategoryId;
  label: string;
  eyebrow: string;
  tagline: string;
  banner: string;
  subcategories?: SubcategoryDef[];
  basePrice: number;
  priceStep: number;
  duration: string;
  area: string;
  includes: string[];
  addons: string[];
};

export type PackageItem = {
  id: string;
  name: string;
  category: CategoryId;
  categoryLabel: string;
  subcategory?: string;
  subcategoryLabel?: string;
  image: string;
  price: number;
  description: string;
  includes: string[];
  duration: string;
  area: string;
  addons: string[];
};

/* ---------------------------------------------------------------------- */
/* Image loading                                                          */
/* ---------------------------------------------------------------------- */

const imageModules = import.meta.glob<string>("/src/assets/pkg/**/*.{jpg,jpeg,png}", {
  eager: true,
  import: "default",
});

const bannerModules = import.meta.glob<string>("/src/assets/pkg/_banners/*.{jpg,jpeg,png}", {
  eager: true,
  import: "default",
});

function bannerFor(categoryId: string): string {
  const entry = Object.entries(bannerModules).find(([path]) => path.includes(`/_banners/${categoryId}.`));
  return entry?.[1] ?? Object.values(bannerModules)[0];
}

/** Returns [path, image] pairs sorted for a given category/subcategory folder, skipping the banners folder. */
function imagesFor(categoryId: string, subId?: string): string[] {
  const folder = `/src/assets/pkg/${categoryId}/${subId ?? "_"}/`;
  return Object.entries(imageModules)
    .filter(([path]) => path.startsWith(folder))
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, img]) => img);
}

/* ---------------------------------------------------------------------- */
/* Category configuration — edit copy, pricing & inclusions here          */
/* ---------------------------------------------------------------------- */

const nameThemes: Record<string, string[]> = {
  "birthday-baby-girl": ["Pastel Princess Balloon Setup", "Unicorn Dream Birthday Decor", "Barbie Sparkle Birthday Theme", "Butterfly Garden Birthday Decor", "Pink Rosegold Birthday Setup", "Floral Fairy Birthday Theme", "Candy Pop Birthday Decor"],
  "birthday-baby-boy": ["Superhero Squad Birthday Decor", "Jungle Safari Birthday Theme", "Little Champ Balloon Setup", "Blue & Gold Birthday Decor", "Cars & Wheels Birthday Theme", "Space Explorer Birthday Decor", "Dino Adventure Birthday Setup"],
  "birthday-twins": ["Twin Stars Birthday Decor", "His & Hers Balloon Setup", "Double Delight Birthday Theme", "Twin Rainbow Birthday Decor"],
  "birthday-adult": ["Golden Elegance Birthday Decor", "Rosegold Glam Birthday Setup", "Chic Balloon Wall Birthday Theme", "Milestone Birthday Grand Decor", "Classic Black & Gold Birthday", "Boho Birthday Balloon Setup"],
  anniversary: ["Heart Canopy Anniversary Decor", "Rose Petal Anniversary Setup", "Golden Glow Anniversary Theme", "Romantic Fairy-light Anniversary", "Elegant Floral Anniversary Decor", "Premium Anniversary Balloon Setup"],
  proposal: ["Marry Me Marquee Proposal", "Heart Balloon Proposal Setup", "Rooftop Rose Proposal Decor", "Candlelight Proposal Backdrop", "Garden Proposal Floral Arch", "Rose Petal Proposal Pathway", "Grand Ring Proposal Decor"],
  "baby-shower-girl": ["Oh Baby Girl Balloon Setup", "Pink Floral Baby Shower Decor", "Little Princess Baby Shower Theme", "Pastel Cloud Baby Shower Decor"],
  "baby-shower-boy": ["Oh Baby Boy Balloon Setup", "Blue Floral Baby Shower Decor", "Little Prince Baby Shower Theme", "Sky Blue Cloud Baby Shower Decor"],
  "baby-shower-twins": ["Double Bundle Baby Shower Decor", "Twin Baby Shower Balloon Setup", "His & Hers Baby Shower Theme"],
  "naming-ceremony-girl": ["Pink Naming Ceremony Decor", "Floral Naming Ceremony Setup", "Elegant Girl Naming Backdrop"],
  "naming-ceremony-boy": ["Blue Naming Ceremony Decor", "Royal Naming Ceremony Setup", "Elegant Boy Naming Backdrop"],
  "naming-ceremony-twins": ["Twin Naming Ceremony Decor", "Double Joy Naming Ceremony Setup", "Twin Blessing Naming Backdrop"],
  haldi: ["Marigold Haldi Backdrop", "Boho Yellow Haldi Setup", "Phoolon Ki Chaadar Haldi", "Traditional Haldi Chowki Decor"],
  mehendi: ["Rajasthani Mehendi Umbrella Decor", "Boho Phoolon Ki Chaadar Mehendi"],
  "ring-ceremony": ["Glittering Ring Ceremony Backdrop", "Royal Gold Ring Ceremony Decor", "Floral Ring Ceremony Stage", "Elegant Ring Ceremony Setup"],
};

const descThemes: Record<string, string> = {
  birthday: "A joyful, premium balloon setup styled with themed props, a personalised banner and photo-ready styling.",
  anniversary: "A romantic anniversary setup with heart canopy, fresh floral touches and warm ambient lighting.",
  proposal: "A grand, camera-ready proposal moment styled with balloons, petals and marquee lighting.",
  "baby-shower": "A dreamy baby shower setup with pastel balloon garlands, floral touches and a personalised banner.",
  "naming-ceremony": "A traditional yet elegant naming ceremony backdrop styled with balloons, drapes and personalised signage.",
  haldi: "A vibrant marigold-and-yellow haldi setup styled with traditional drapes and floral accents.",
  mehendi: "A colourful mehendi night setup with umbrellas, drapes and cushioned low seating styling.",
  "ring-ceremony": "A statement ring ceremony backdrop styled with balloons, florals and premium stage lighting.",
};

export const categories: CategoryDef[] = [
  {
    id: "birthday",
    label: "Birthday Decoration",
    eyebrow: "Birthday Celebrations",
    tagline: "Themed balloon setups for every little (and big) birthday star.",
    banner: bannerFor("birthday"),
    subcategories: [
      { id: "baby-girl", label: "Baby Girl" },
      { id: "baby-boy", label: "Baby Boy" },
      { id: "twins", label: "Twins" },
      { id: "adult", label: "Adult" },
    ],
    basePrice: 4499,
    priceStep: 550,
    duration: "2–4 hours",
    area: "Indoor / home venue, up to 200 sq.ft",
    includes: [
      "150+ premium latex & foil balloons",
      "Personalised “Happy Birthday” foil banner",
      "Curtain / fabric backdrop styling",
      "LED fairy light accents",
      "Cake table & prop styling",
      "Themed props and confetti balloons",
    ],
    addons: ["Photographer (2 hrs)", "LED name board upgrade", "Premium cake table styling", "Extra character cutouts"],
  },
  {
    id: "anniversary",
    label: "Anniversary Decoration",
    eyebrow: "Anniversary Celebrations",
    tagline: "Romantic, elegant setups to celebrate every year of love.",
    banner: bannerFor("anniversary"),
    basePrice: 4999,
    priceStep: 600,
    duration: "2–3 hours",
    area: "Bedroom / hall, up to 150 sq.ft",
    includes: [
      "Heart-shaped balloon canopy",
      "Rose petal pathway & bed art",
      "Fresh floral & mood lighting",
      "Personalised name / date banner",
      "Curtain backdrop with LED accents",
      "Cake / champagne table styling",
    ],
    addons: ["Fresh flower bouquet", "Photographer (2 hrs)", "Cake (1kg, on request)", "Candlelight dinner setup"],
  },
  {
    id: "proposal",
    label: "Proposal Decoration",
    eyebrow: "Proposal Moments",
    tagline: "Say it with a moment they'll never forget.",
    banner: bannerFor("proposal"),
    basePrice: 6999,
    priceStep: 700,
    duration: "2–3 hours",
    area: "Indoor / rooftop / outdoor, up to 200 sq.ft",
    includes: [
      "Giant heart / ring balloon backdrop",
      "Rose petal 'Marry Me' floor art",
      "LED marquee sign styling",
      "Floral aisle & pathway petals",
      "Champagne & ring table styling",
      "Fairy light ambience",
    ],
    addons: ["Photographer coordination", "LED 'Marry Me' marquee upgrade", "Fresh rose bouquet", "Live violinist (on request)"],
  },
  {
    id: "baby-shower",
    label: "Baby Shower",
    eyebrow: "Baby Shower Celebrations",
    tagline: "Dreamy pastel setups to celebrate the mother-to-be.",
    banner: bannerFor("baby-shower"),
    subcategories: [
      { id: "girl", label: "Baby Girl" },
      { id: "boy", label: "Baby Boy" },
      { id: "twins", label: "Twins" },
    ],
    basePrice: 4499,
    priceStep: 550,
    duration: "2–4 hours",
    area: "Indoor / home venue, up to 200 sq.ft",
    includes: [
      "Full balloon garland backdrop",
      "“Oh Baby / Mom-to-be” foil banner",
      "Themed cake table styling",
      "Fresh floral touches",
      "Photo booth props & sash",
      "Custom sign board (name / date)",
    ],
    addons: ["Photographer (2 hrs)", "Mom-to-be sash & crown upgrade", "Games & props kit", "Premium cake table styling"],
  },
  {
    id: "naming-ceremony",
    label: "Naming Ceremony",
    eyebrow: "Naming Ceremony",
    tagline: "Traditional, elegant backdrops to welcome the little one's name.",
    banner: bannerFor("naming-ceremony"),
    subcategories: [
      { id: "girl", label: "Baby Girl" },
      { id: "boy", label: "Baby Boy" },
      { id: "twins", label: "Twins" },
    ],
    basePrice: 4499,
    priceStep: 550,
    duration: "3–4 hours",
    area: "Indoor hall / home venue, up to 250 sq.ft",
    includes: [
      "Balloon garland backdrop with name signage",
      "Traditional cradle / stage styling",
      "Fresh floral touches",
      "LED fairy light accents",
      "Photo booth props",
      "Personalised name banner",
    ],
    addons: ["Photographer (2 hrs)", "Cradle floral styling upgrade", "Premium name board", "Return-gift table styling"],
  },
  {
    id: "haldi",
    label: "Haldi Decoration",
    eyebrow: "Haldi Ceremony",
    tagline: "Bright marigolds and traditional styling for a joyful haldi.",
    banner: bannerFor("haldi"),
    basePrice: 5999,
    priceStep: 700,
    duration: "3–4 hours",
    area: "Indoor / outdoor lawn, up to 300 sq.ft",
    includes: [
      "Marigold & yellow floral backdrop",
      "Traditional dhoti / dupatta drapes",
      "Brass urli & petal floor decor",
      "Yellow balloon garland accents",
      "Personalised name / couple signage",
      "Chowki & seating styling",
    ],
    addons: ["Photographer (2 hrs)", "Extra marigold strands", "Dhol / traditional music coordination", "Chowki upgrade"],
  },
  {
    id: "mehendi",
    label: "Mehendi Decoration",
    eyebrow: "Mehendi Night",
    tagline: "Colourful drapes and umbrellas for a vibrant mehendi night.",
    banner: bannerFor("mehendi"),
    basePrice: 6499,
    priceStep: 750,
    duration: "3–5 hours",
    area: "Indoor / outdoor lawn, up to 300 sq.ft",
    includes: [
      "Colourful phoolon-ki-chaadar backdrop",
      "Rajasthani umbrella & jhula styling",
      "Bright dupatta drapes & tassels",
      "Floor cushions & low seating decor",
      "Mehendi station styling",
      "Personalised couple signage",
    ],
    addons: ["Photographer (2 hrs)", "Extra umbrellas & tassels", "Mehendi artist coordination", "Live music coordination"],
  },
  {
    id: "ring-ceremony",
    label: "Ring Ceremony",
    eyebrow: "Ring Ceremony",
    tagline: "Statement ring backdrops for the perfect 'yes'.",
    banner: bannerFor("ring-ceremony"),
    basePrice: 6999,
    priceStep: 800,
    duration: "3–4 hours",
    area: "Indoor hall / banquet, up to 300 sq.ft",
    includes: [
      "Giant ring-shaped balloon backdrop (6ft+)",
      "Custom foil name / initials",
      "Floral & fairy light accents",
      "Rose petal pathway",
      "Stage & seating styling",
      "Cake / ring platform styling",
    ],
    addons: ["Photographer (2 hrs)", "Stage lighting upgrade", "Fresh floral arch", "Premium ring platform styling"],
  },
];

export const categoryMap = new Map(categories.map((c) => [c.id, c]));

/* ---------------------------------------------------------------------- */
/* Build the full package list from images + category config              */
/* ---------------------------------------------------------------------- */

function buildPackages(): PackageItem[] {
  const items: PackageItem[] = [];

  for (const cat of categories) {
    const subs: (SubcategoryDef | undefined)[] = cat.subcategories?.length ? cat.subcategories : [undefined];

    for (const sub of subs) {
      const imgs = imagesFor(cat.id, sub?.id);
      const themeKey = sub ? `${cat.id}-${sub.id}` : cat.id;
      const names = nameThemes[themeKey] ?? [];
      const desc = descThemes[cat.id] ?? "A premium themed decoration setup styled by Decoration Kingdom.";

      imgs.forEach((image, i) => {
        const id = sub ? `${cat.id}-${sub.id}-${i + 1}` : `${cat.id}-${i + 1}`;
        items.push({
          id,
          name: names[i % Math.max(names.length, 1)] ?? `${cat.label} Package ${i + 1}`,
          category: cat.id,
          categoryLabel: cat.label,
          subcategory: sub?.id,
          subcategoryLabel: sub?.label,
          image,
          price: cat.basePrice + i * cat.priceStep,
          description: desc,
          includes: cat.includes,
          duration: cat.duration,
          area: cat.area,
          addons: cat.addons,
        });
      });
    }
  }

  return items;
}

export const allPackages: PackageItem[] = buildPackages();

export function getCategory(categoryId: string) {
  return categories.find((c) => c.id === categoryId);
}

export function getSubcategories(categoryId: string) {
  return getCategory(categoryId)?.subcategories ?? [];
}

export function getPackages(categoryId: string, subId?: string) {
  return allPackages.filter((p) => p.category === categoryId && (subId ? p.subcategory === subId : true));
}

export function findPackageById(id: string) {
  return allPackages.find((p) => p.id === id);
}

export const inr = (n: number) => "₹" + n.toLocaleString("en-IN");
